to run the code via spyders command line, use the following format : 

%run template.py <numstep> <dt> <particle file> <xyz outfile> <OPTIONAL out>

numstep - number of steps the loop performs
dt - timestep between each iteration
particle file - name of file storing particle data
xyz file - name of file data will be written out to for each time step in XYZ format
